#pragma once
#include <iostream>
using namespace std;
#include "Contact.h"
#include <fstream>


class PhoneBook{


    
    private:
    int number;
    int number2;
    Contact* arrary[] = new Contact[number2];

    int addContact(Contact* contacts){
        number2 = 5;
        array[number];
        cout <<"enter the first name, lastname and phone number"<<endl;
        if (number<5){
        cin>> * array[number];
        Contact other;
        
        bool answer = other.operator==(other);
        if (answer==true){
        number++;
        cout<<"success!"<<endl;
        }
        else
        cout<<"error!"<<endl;


        }

    }
    void saveContactFile(Contact& contacts){
        
        ofstream f; 
        string line;


        f.open("contacts.txt", ios::app);
        if (f.is_open()){
            int number  =1;
        while(array[number]!=5){
            f << line << endl;
            if(array[number]!=NULL)
            cout<<"success"<<endl;
            else
            cout<<"number not saved"<<endl;
        }
        
            
        }
        else
        cout<<"error! file not opened"<<endl;
    
    }
    void showContactFile(Contact& contacts){

    }

    public:
    PhoneBook();
    void run() {
        int i;
        cout<<"choose operation of your choice\n1 add\n2 show all contacts\n3 save contacts\n4 quit"<<endl;
        cin>>i;
        while (true)
        {
            Contact other;
            switch (i)
            {
                
            case  1:addContact( Contact* array);break;
            break;
            case 2:showContactFile( Contact* array);
                break;
                case 3:saveContactFile( Contact* array);
                break;
                case 4: exit(1); 
                break;
            
        
            }
        }


};