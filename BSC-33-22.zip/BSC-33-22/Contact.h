#pragma once
#include <string>
#include <iostream> 
using namespace std;

class Contact {

    private:
    string firstName;
    string lastName;
    int phoneNumber;

    public:
    //setters
    void setFirstname(string fName);
    void setLastname(string lName);
    void setPhoneNumber(int phoneNumber);

    //getters
    string getFirstname() const;
    string getLastname() const;
    string getPhoneNumber() const;

    //other function
    bool operator==(Contact& other){
        if(this->phoneNumber == other.phoneNumber)
        return true;
        else return false;

    }

    //constractors
    Contact(){
        firstName = "";
        lastName = "" ;
        phoneNumber = 000000000;
    }

    Contact(string fName, string lName,int phone){
        firstName = fName;
        lastName = lName;
        phoneNumber = phone;
    }
    
};