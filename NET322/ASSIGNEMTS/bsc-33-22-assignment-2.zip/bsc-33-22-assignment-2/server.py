import asyncio
from pathlib import Path
import argparse

import logging

APPLOGER = logging.getLogger(name='HTTP-SERVER')

handle_loger = logging.StreamHandler()
APPLOGER.setLevel(logging.DEBUG)
handle_loger.setFormatter(fmt=logging.Formatter(fmt="[%(levelname)s] %(name)s : %(asctime)s > %(message)s",
                                                   datefmt="%Y-%m-%d %H:%M:%S"))
APPLOGER.addHandler(handle_loger)


# command line arguments
def parse_args():
    parser = argparse.ArgumentParser(description='HTTP PORT AND ADDRESS ENTREY')
    parser.add_argument("--host",type=str,default="127.0.0.1",help="host address to bind the server")
    parser.add_argument("--port",type=int,required=True,help="port number")

    return parser.parse_args()

    #path of static file resolution
path1 = Path(__file__).parent / 'templates/index.html'
path2 = Path(__file__).parent / 'templates/register.html'
assets_dir = Path(__file__).parent / 'assets'
path = Path(__file__).parent / 'assets/networking_background.jpg'


async def handle_client(reader, writer):
    addr = writer.get_extra_info('peername')
    APPLOGER.debug(msg=f"handled HTTP-CLIENT {addr[0]}:{addr[1]} request")
    while True:
    
        data = await reader.read(1024)
        if not data:
            break
            
            # Parse HTTP method and path
        meth_path = data.decode().split(' ')[:2]
        method = meth_path[0]
        path = meth_path[1]

        if method == "GET" and path == '/':
            with open(path1, 'r', encoding='utf-8') as file:
                html = file.read()
                await response(content_type="text/html; charset=UTF-8", writer=writer, body=html)

        elif method == "GET" and path == "/register":
            with open(path2, 'r', encoding='utf-8') as file:
                html = file.read()
            await response(content_type="text/html; charset=UTF-8", writer=writer, body=html)
            
        # handling image get request
        elif method == "GET" and path.startswith('/assets/'):
            asset_path = assets_dir / path.split('/assets/')[1]
            if asset_path.exists():
                with open(asset_path, 'rb') as file:
                     content = file.read()
                    # Adjust response for binary data (e.g., images)
                await response(content_type="image/jpeg", writer=writer, body=content, binary=True)
            else:
                await response(content_type="text/plain", writer=writer, body="Asset not found", status_code=404)

            # response to post request
        elif method == "POST" and (path == "/submit" or path == '/register'):
            content_requst_post = data.decode().split('=')
            email =content_requst_post[11]
            username = content_requst_post[10].split('&')[0]
            
             # Writing to a file
            text = f"---bash\n{username} {email}\n---\n"
            with open('db.txt', 'a') as file:
                file.write(text)

                # Notifying client
            response_body = "Goal set. Data sent successfully."
            await response(content_type="text/plain", writer=writer, body=response_body)

        else:
            body = "Page not found"
            await response(content_type="text/plain", writer=writer, body=body, status_code=404)
            await writer.wait_closed()
            break

async def response(content_type, body, writer, status_code=200, binary=False):
    if binary:
        # Binary response for assets like images
        http_response = (
            f"HTTP/1.1 {status_code} OK\r\n"
            f"Content-Type: {content_type}\r\n\r\n"
        ).encode() + body
    else:
        # Text-based response
        http_response = (
            f"HTTP/1.1 {status_code} OK\r\n"
            f"Content-Type: {content_type}\r\n\r\n{body}"
        ).encode()
    
    writer.write(http_response)
    await writer.drain()


async def main():
    #argumets
    args = parse_args()
    address = args.host
    port = args.port
    #server 
    server = await asyncio.start_server(handle_client, address, port)
    addr = server.sockets[0].getsockname()
    APPLOGER.debug(msg=f"Running on http://{addr[0]}:{addr[1]}") 

    async with server:
        await server.serve_forever()


if __name__ == "__main__":
    asyncio.run(main())