import asyncio
import argparse

def parse_args():
    pass

connected_clients = set()
address = input("addr >>: ")
port = input("port>>: ")

async def handle_client(reader, writer):
    # Register client
    connected_clients.add(writer)
    addr = writer.get_extra_info('peername')
    print(f"New connection from {addr}")

    try:
        while True:
            data = await reader.read(100)
            if not data:
                break
            message = data.decode().strip()
            print(f"Received: {message} from {addr}")
            
            # Broadcast message to other clients
            for client in connected_clients:
                if client != writer:
                    client.write(f"{addr}: {message}\n".encode())
                    await client.drain()
    except ConnectionResetError:
        print(f"Connection lost from {addr}")
    finally:
        # Clean up
        print(f"Closing connection from {addr}")
        connected_clients.remove(writer)
        writer.close()
        await writer.wait_closed()

async def main():
    server = await asyncio.start_server(handle_client, address, port)
    print(server)
   # print("Server started on 127.0.0.1:8888")
    
    async with server:
        await server.serve_forever()

asyncio.run(main())